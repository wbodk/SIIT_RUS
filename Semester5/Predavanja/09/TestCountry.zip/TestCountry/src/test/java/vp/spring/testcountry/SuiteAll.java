package vp.spring.testcountry;

import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;

import vp.spring.testcountry.data.CountryRepositoryIntegrationTest;
import vp.spring.testcountry.data.CountryRepositoryUnitTest;
import vp.spring.testcountry.service.CountryServiceIntegrationTest;
import vp.spring.testcountry.service.CountryServiceUnitTest;
import vp.spring.testcountry.web.controller.CountryControllerTest;

@Suite
@SelectClasses({CountryRepositoryUnitTest.class, 
		CountryRepositoryIntegrationTest.class,
		CountryServiceUnitTest.class,
		CountryServiceIntegrationTest.class,
		CountryControllerTest.class})
public class SuiteAll {

}
