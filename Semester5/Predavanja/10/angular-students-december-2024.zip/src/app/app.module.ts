import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app.routing';
import { HttpClientModule } from '@angular/common/http';

import {NgbModule} from '@ng-bootstrap/ng-bootstrap';

import { AppComponent } from './app.component';
import { StudentsComponent } from './students/students.component';
import { CoursesComponent } from './courses/courses.component';
import { StudentService } from './students/student.service';
import { CommonModule } from '@angular/common';
import { CourseService } from './courses/course.service';
import { EnrollmentService } from './enrollments/enrollment.service';
import { StudentDetailComponent } from './student-detail/student-detail.component';
import { CourseDetailComponent } from './course-detail/course-detail.component';
import { EnrollmentDetailComponent } from './enrollment-detail/enrollment-detail.component';
import { TestComponentComponent } from './test-component/test-component.component';

@NgModule({
  declarations: [
    AppComponent,
    StudentsComponent,
    CoursesComponent,
    StudentDetailComponent,
    CourseDetailComponent,
    EnrollmentDetailComponent,
    TestComponentComponent
  ],
  imports: [
    FormsModule,  
    NgbModule,
    CommonModule,
    BrowserModule,
    HttpClientModule,
    AppRoutingModule
  ],
  providers: [StudentService, CourseService, EnrollmentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
